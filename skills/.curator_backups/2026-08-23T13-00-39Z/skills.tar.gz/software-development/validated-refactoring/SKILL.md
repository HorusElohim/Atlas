---
name: validated-refactoring
description: "Remove dead code; run gate; tests pass before commit."
trigger: "User asks to remove dead code or refactor with validation requirements."
---

# Validated Refactoring Workflow

A class-level skill for refactoring tasks where the user requires:
1. **Actual dead code removal** - not `#[allow(dead_code)]` or `#[allow(unused_imports)]` suppression
2. **Project-specific validation gate** - run the project's test script (e.g., `./tests/nexus.sh`) before committing
3. **Full test suite pass** - `cargo test` / equivalent must pass
4. **Project commit conventions** - emoji + conventional commits (🐛 fix, ✨ feat, 📚 docs, etc.)

## Core Principles

### Remove, Don't Suppress
- User explicitly rejects `#[allow(dead_code)]` and `#[allow(unused_imports)]` as solutions
- If code is truly unused, **delete it** - including the `#[allow(...)]` attributes
- Only retain `#[allow(dead_code)]` for test-only utilities that clippy falsely flags (and only when deletion would reduce test coverage of production paths)

### Validation Gate is Mandatory
- Identify the project's validation script (often `./tests/*.sh`, `make test`, `just test`, etc.)
- Run it **before** committing - user validates locally too
- Fix all failures before `git commit`

### Directory-Aware Commands
- Cargo commands must run from the crate root (e.g., `portalis/rust/backend/`, not repo root)
- `CARGO_BUILD_JOBS=2` for shared/limited hosts
- `cargo fmt --all` before check/test

## Workflow Steps

1. **Inventory dead code**: `git grep -n 'allow(dead_code)\|unused_import'` + usage search
2. **Determine fate**: delete if truly dead, keep with `#[allow(dead_code)]` only if test-only utility
3. **Remove code + attributes**: delete the items AND their `#[allow(...)]` markers
4. **Run validation**: `./tests/nexus.sh` (or project equivalent)
5. **Run full test suite**: `cargo test --workspace` / equivalent
6. **Format**: `cargo fmt --all` (and `dart format .` if Flutter)
7. **Commit**: emoji + type + short message
8. **Push**: rebase on origin first

## Pitfalls

- **Don't assume** `cargo check` from repo root works - find the `Cargo.toml`
- **Don't suppress** with `#[allow(...)]` unless user explicitly accepts it for test-only code
- **Don't skip** the validation script - user runs it locally and will catch failures
- **Don't forget** FRB regeneration for Flutter/Rust projects after API changes

## Project-Specific Notes (PortalisApp)

- Validation: `./tests/nexus.sh` (runs from repo root, enforces `-D warnings`)
- Cargo dir: `portalis/rust/backend/`
- Commit style: `🐛 fix: ...`, `✨ feat: ...`, `📚 docs: ...`
- FRB regen: `./tool/frb_build.sh` after Rust API changes
- Version bumps: `pubspec.yaml` + `Cargo.toml` + `CHANGELOG.md`