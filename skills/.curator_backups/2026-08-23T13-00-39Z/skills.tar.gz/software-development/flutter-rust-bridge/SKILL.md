---
name: flutter-rust-bridge
description: "Use for Flutter-Rust bridge generation and API changes."
version: 1.0.0
---

# Flutter-Rust Bridge Engineering

## Use when

Use this skill when a Flutter application calls Rust through
`flutter_rust_bridge` (FRB): changing a bridged function or DTO, regenerating
bindings, reviewing generated output, or diagnosing codegen/build mismatches.

## Principles

- Keep the bridge **app-facing and explicit**. Export small DTOs and functions
  designed for Flutter; do not expose internal stores, core handles, traits, or
  domain graphs merely because codegen can see them.
- Generated bindings are build artifacts, not hand-maintained source. Change
  Rust inputs and generator configuration, then regenerate; never patch
  generated Dart or Rust as the lasting fix.
- Keep expensive or fast-moving state tiered. Prefer explicit summary, detail,
  history, and command channels over one universal snapshot that increases
  bridge traffic and Flutter allocation.
- Treat external links and QR payloads as untrusted input. Validate them before
  dispatching a bridged command; do not let a UI handle or display identifier
  masquerade as a durable cross-device identifier.

## Workflow

1. **Trace the current boundary.** Read the generator helper, its explicit Rust
   inputs, the public Rust API, generated Dart facade, app adapter, consumers,
   and test fakes before editing.
2. **Write a focused red test.** Cover the app-facing behavior or the smallest
   core boundary. Test an absent/invalid value as well as the successful bridge
   value where relevant.
3. **Change the real Rust boundary.** Keep DTOs owned and serializable. Return
   explicit `Option`/`Result` values instead of sentinel strings or invented
   identifiers.
4. **Regenerate once.** Invoke the repository helper from the directory it
   expects. Review every generated change; retain only output attributable to
   the intentional Rust/public-dependency change.
5. **Normalize generated Rust in the helper.** Some FRB versions emit Rust
   import ordering that fails `cargo fmt --check` despite compiling. Put
   `cargo fmt --all` immediately after codegen in the repository helper, then
   rerun the helper. Never manually format `src/api.rs` and call it fixed.
6. **Update adapter seams and test fakes.** An added repository/gateway method
   requires every fake implementation to implement it, usually with the most
   truthful unavailable/default response.
7. **Verify the combined tree.** Run the focused tests, Flutter analysis and
   suite, the generator, Rust formatting, and the repository Rust acceptance
   gate. Report target-specific build checks honestly when the required SDK is
   unavailable.

## Diagnosing generator messages

- A codegen diagnostic about duplicate internal type names or skipped
  unsupported internal types is not automatically a release failure. First
  inspect the generated public API and compile the generated Rust.
- It becomes a correctness problem if the ambiguous or skipped type is present
  in an exported function or DTO. Fix the public boundary—rename/contain the
  internal type or define a dedicated app-facing DTO—rather than suppressing
  diagnostics or exposing internals as opaque solely to hide a message.
- A generator run is successful only when it exits zero **and** the generated
  bindings compile through the repository's normal Rust/Flutter gates.

## Verification checklist

```sh
# From the Flutter package root
./tool/frb_build.sh
flutter analyze
flutter test

# From the Rust workspace root, or use the repository acceptance helper
cargo fmt --all --check
cargo test --workspace --all-targets --all-features
```

Follow any repository-specific integration/coverage script as the final gate.

## Pitfalls

- Using a bare crate-wide generator input in a complex crate and accidentally
  traversing internal modules that are not bridgeable.
- Hand-editing generated files after codegen.
- Adding a method to the production adapter but forgetting test fakes.
- Treating a process-local backend handle as an importable or shareable ID.
- Claiming an iOS/Android deep-link handoff passed without installing a new
  native build and testing it on the device.

## Reference

- `references/generated-output-hygiene.md` — compact notes on formatting FRB
  output and reviewing generator diagnostics.
