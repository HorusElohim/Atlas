---
name: rust-test-triage
description: "Use for Rust test failures; preserve exact suite context."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [rust, testing, debugging, flaky-tests, regression]
    related_skills: [systematic-debugging, shared-dev-host-safety, test-driven-development]
---

# Rust Test Triage

Use for Rust workspace test failures, especially when the user wants concise
output or when a failure may be flaky, stale, or caused by a recent refactor.

## Workflow

1. **Run the exact reported command first.** Preserve the original package,
   test target, suite, thread count, setup, and environment. A narrower test is
   useful only as a diagnostic follow-up, never as proof that the reported
   failure is fixed.
2. **Bound evidence.** Capture the failing test, relevant source range, recent
   commits touching the path, and the final test summary. Avoid dumping an
   entire workspace log.
3. **Trace before changing.** For assertion mismatches, locate the assertion,
   the producer of the returned value, and recent changes. Check implicit side
   effects and deterministic ordering. In storage tests, verify automatic
   membership/ownership effects and key ordering before changing expectations.
4. **Classify accurately.** If an isolated rerun passes, report “not reproduced
   in isolation” and rerun the original suite before calling it flaky. Preserve
   the suite's concurrency and lifecycle when validating a suspected race.
5. **Make the smallest root-cause change.** If behavior is intentional and the
   assertion is stale, update only that focused expectation. Do not alter
   production behavior to satisfy an outdated test.
6. **Verify proportionally.** Run the focused test, then the relevant package
   `cargo fmt --all --check` and `cargo clippy -p <package> --all-targets
   --all-features -- -D warnings`. Run broader checks when resources permit;
   state skipped checks honestly.
7. **Before push**, fetch/rebase origin, rerun affected checks if the rebase
   touched the same area, then push and verify the remote commit.

## Minimal-output mode

When the user requests token efficiency, use terse tool commands and bounded
output. The final handoff should contain only:

- root cause;
- file and line/region changed;
- exact verification result;
- commit/push status;
- broader checks not run.

Do not narrate every investigation step or present an isolated green test as a
resolved suite failure.

## Common patterns

### Stale expectation after an intentional side effect

Trace the write path and compare the expected collection with the actual table
ordering. Update the expectation and add a short assertion message explaining
the intentional side effect, such as automatic owner membership.

### Handshake or timing failure

First rerun the exact suite. Then run the test in isolation to compare. If only
parallel/contextual execution fails, investigate lifecycle, address reservation,
shutdown, and retry behavior; do not immediately label it a product bug.

### Compile/clippy mismatch after sync/async refactor

Search all callers after changing a method's asyncness. Remove stale `.await`
expressions and update tests from async runtime attributes only when no await
remains. Run clippy with `-D warnings` so unused async and cast lints are not
missed.

## Reference

See `references/portalis-rust-failure-patterns.md` for concise examples from
Portalis storage and client test failures.
