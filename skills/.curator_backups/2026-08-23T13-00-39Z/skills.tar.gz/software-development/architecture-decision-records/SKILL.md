---
name: architecture-decision-records
description: "Use when implementing or governing ADR-driven architecture."
version: 1.0.0
---

# Architecture Decision Records

## Purpose

Use this skill when a repository treats Architecture Decision Records (ADRs) as
its durable architectural history and the codebase as the current-state map.
It governs creating, implementing, accepting, superseding, and cleaning up
architecture decisions without turning documentation back into a mutable second
source of truth.

## Core model

- **Code is the current-state map.** Inspect the working tree before making
  claims about an implementation.
- **ADRs are frozen history.** Do not rewrite old ADR text to match a later
  refactor; supersede it with a new ADR when the decision changes.
- **The ADR index is the entry point.** Keep its number, title, status, and
  supersession data accurate under the repository's status convention.
- **One architectural decision, one atomic implementation.** Keep structural,
  bridge, generated-binding, test, and changelog changes together when they are
  one behavior change.

## Implementing an ADR

1. Fetch `origin/main`, branch from it, and read both the ADR and its index
   entry before changing code.
2. Translate each Decision and Consequence bullet into verifiable repository
   acceptance criteria. Inspect the actual implementation and test paths; do
   not rely on ADR prose as evidence that work landed.
3. Preserve stable public boundaries. For a bridge refactor, trace generated
   types, application seams, widget consumers, and tests before deleting a
   wrapper or renaming an import.
4. Prefer one explicit test seam over several pass-through interfaces. A
   gateway/facade may expose tiered streams and commands; “one seam” does not
   require collapsing materially different data rates into one oversized
   snapshot.
5. Delete obsolete implementation and documentation in the same change. Do not
   leave compatibility paths, stale mirrors, or dead documents merely to retain
   history.
6. Add/update focused tests first when behavior changes. Run the smallest
   affected suite, then the repository gate before committing.

## Retiring a living specification or plan

When an ADR replaces a central mutable specification with frozen ADRs:

1. Delete the live central design, migration-plan, and explicitly contradicted
   narrative documents named by the decision.
2. Replace every **active** README, source-comment, script, manifest, and doc
   reference with either code-local explanation or the ADR index.
3. Keep historical references in frozen ADRs intact. They record the decision
   context at the time it was made, even if their former paths are gone.
4. Preserve focused feature acceptance notes unless they actually recreate a
   central architecture specification.
5. Search for all retired document names after editing. The only remaining
   references should be intentional frozen-history mentions.

## Flutter/Rust bridge refactors

For a generated Flutter-Rust bridge:

- Use generated bridge DTOs directly as the application data types where they
  already express the backend contract.
- Avoid hand-written field-for-field DTO mirrors and command envelopes.
- A small factory that returns the generated command DTO is acceptable when it
  only supplies mandatory empty fields or converts an input into the generated
  typed buffer; it must not create a second domain model.
- Preserve deliberately tiered contracts such as summary snapshots, selected
  detail streams, and append-only history streams. Packing detail/history into
  every snapshot trades a few wrappers for persistent bridge and memory cost.
- Regenerate bindings whenever a bridged Rust signature or DTO changes, and
  review generated diffs as part of the same atomic change.

## Verification

Before commit, verify all of the following that apply:

```sh
# Documentation retirement
# Search for retired document names and inspect every surviving hit.

# Flutter application changes
flutter analyze
flutter test <focused tests>
flutter test

# Rust/backend changes
cargo fmt --all --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --all-features
./tests/nexus.sh
```

Record skipped target-specific checks honestly. A missing SDK or cross compiler
is not proof a platform build passes.

## Pitfalls

- Treating an ADR as a living implementation document and editing it after the
  fact.
- Deleting an ADR's historical path mentions along with the retired files.
- Replacing several low-rate, on-demand streams with one universal snapshot.
- Calling a reference-holding view a deep copy without inspecting its fields.
- Renaming a pass-through seam without updating its test fake and focused
  controller tests in the same change.
- Claiming cross-platform compilation passed when the host stopped earlier for
  a missing SDK or compiler.
