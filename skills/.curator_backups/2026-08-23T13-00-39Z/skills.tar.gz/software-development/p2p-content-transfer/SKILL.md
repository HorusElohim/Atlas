---
name: p2p-content-transfer
description: "Use when P2P sharing needs discovery, QR, or transfer debug."
trigger: "Use when implementing or debugging P2P file/media transfer, QR bootstrap, direct peer hints, LAN discovery, or receiver-side download flows."
---

# P2P Content Transfer

## Purpose

Use this skill for peer-to-peer file or media transfer systems where one device publishes content and another receives it through a QR code, deep link, magnet, descriptor, LAN endpoint, tracker, DHT, or direct connection.

The central rule is to keep **content identity** separate from **rendezvous information**:

- An info-hash or content ID says **what** the receiver wants.
- A peer endpoint, tracker, DHT, or discovery service says **where** the receiver can find a seeder.
- Being on the same Wi-Fi does not provide rendezvous by itself.

## Non-Negotiable Invariants

1. **Zero-copy source ownership** — Never copy, clone, stage, or duplicate source media merely to publish it. Persist only metadata, descriptors, and endpoint hints.
2. **Sender/receiver separation** — A receiver imports and downloads remote content. It must never invoke sender-only publication actions against local sources.
3. **Truthful identity** — Do not label a process-local collection handle as a content hash, or an address as usable unless it is an actual routable endpoint.
4. **Validated bootstrap data** — Treat QR/deep-link inputs as untrusted. Validate scheme, content ID, endpoint address, port, cardinality, and private/public scope before handing them to the engine.

## Debugging Workflow

### 1. Build the transfer map

Write the actual path down before editing:

```text
sender sources → descriptor/info-hash → QR/deep link → receiver parser
→ rendezvous hints → engine initial peers → metadata resolution → selection → download
```

At every arrow, identify the value that crosses the boundary. Do not infer it from UI state.

### 2. Diagnose “waiting”, “no peers”, or unresolved metadata

Check in this order:

1. Does the receiver have a valid content ID?
2. Does it have a discovery path: direct peer hint, tracker, DHT, or service lookup?
3. Does the engine receive those hints as its initial peers?
4. Is the sender actually seeding and listening on a bound TCP/UDP port?
5. Is that endpoint reachable from the receiver’s network and platform permissions?

A peer count of zero with an unresolved file list usually means the receiver has identity but no rendezvous path.

### 3. Bootstrap QR imports correctly

For in-person same-LAN sharing, include one or more direct peer hints in the inner P2P descriptor/magnet. Use the sender's:

- actual runtime listener port from the P2P engine;
- non-loopback, private LAN interface addresses;
- validated and bounded endpoint list.

Never derive a peer hint from a configured port range or a hard-coded conventional port. The configured range may not be the port the engine bound.

Wrap the descriptor in an app-owned deep link only for OS routing. Preserve the complete inner descriptor—including peer hints—through decode and validation.

### 4. Keep receiver actions receiver-only

A collection QR should follow this sequence:

```text
import remote descriptor
→ wait for metadata/file list
→ select intended entries
→ issue receiver-side download selection
```

It must not call a sender-only `publish`, `publishDraft`, or equivalent action. If manual imports require file selection, use a receiver-specific action label such as “Download selected files,” never “Share.”

### 5. Test before platform handoff

Create deterministic tests before changing implementation:

- share payload encodes direct endpoint hints;
- receiver parser reconstructs the exact endpoint list;
- engine bootstrap receives those peers;
- a collection-link/import flow sends import then download-selection, never publication;
- UI labels local handles, content hashes, and peer state honestly.

Then rebuild both devices and scan a **fresh** QR. Old QR values cannot acquire newly added metadata.

## Platform Considerations

- On iOS, declare local-network usage and handle the permission prompt. Use registered app URL schemes only for opening the app; the P2P engine still needs a real peer endpoint.
- On Android, do not substitute cache-file copies for gallery, MediaStore, or SAF sources. Add native random-access adapters for URI-backed media.
- For native galleries/files, retain platform references and read the original asset in the P2P storage adapter.

## Verification Checklist

- [ ] Sender is actively carrying/seeding the collection.
- [ ] Sender has a real bound listener port.
- [ ] Fresh QR contains a valid content ID and direct peer hints when using LAN bootstrap.
- [ ] Receiver parser preserves the hints.
- [ ] Receiver observes a nonzero peer or a concrete connection error rather than an unexplained wait.
- [ ] Receiver sends download-selection, never sender publication.
- [ ] No media source bytes were copied to make publication/discovery work.
- [ ] Relevant unit, integration, and device tests have passed.

## Common Pitfalls

- **“They are on the same network.”** This is network reachability, not discovery. Carry an endpoint or use an actual discovery mechanism.
- **Hard-coded `6881`.** The P2P engine may bind another available port in its configured range.
- **Raw info-hash QR.** It may identify the swarm without giving a private receiver any route to it.
- **Overloading drafts.** A local unpublished collection and a remote unresolved import are different workflows; never reuse sender terminology for receiver actions.
- **Copying to solve permissions.** Staging bytes creates storage and ownership bugs. Fix the native random-access source adapter instead.
- **Testing only parsing.** A valid QR parser proves nothing unless the endpoint reaches engine initial-peer configuration.

## References

- `references/portalis-qr-lan-bootstrap.md` — validated Portalis seam, regression cases, and zero-copy constraints.
