---
name: p2p-content-transfer
description: "Use when P2P sharing needs discovery, QR, or transfer debug."
trigger: "Use when implementing or debugging P2P file/media transfer, QR bootstrap, direct peer hints, LAN discovery, or receiver-side download flows."
---

# P2P Content Transfer

## Purpose

Use this skill for peer-to-peer file or media transfer systems where one device publishes content and another receives it through a QR code, deep link, magnet, descriptor, LAN endpoint, tracker, DHT, or direct connection.

The central rule is to keep **content identity** separate from **rendezvous information**:

- An info-hash or content ID says **what** the receiver wants.
- A peer endpoint, tracker, DHT, or discovery service says **where** the receiver can find a seeder.
- Being on the same Wi-Fi does not provide rendezvous by itself.

## Non-Negotiable Invariants

1. **Zero-copy source ownership** — Never copy, clone, stage, or duplicate source media merely to publish it. Persist only metadata, descriptors, and endpoint hints.
2. **Sender/receiver separation** — A receiver imports and downloads remote content. It must never invoke sender-only publication actions against local sources.
3. **Truthful identity** — Do not label a process-local collection handle as a content hash, or an address as usable unless it is an actual routable endpoint.
4. **Validated bootstrap data** — Treat QR/deep-link inputs as untrusted. Validate scheme, content ID, endpoint address, port, cardinality, and private/public scope before handing them to the engine.

## Debugging Workflow

### 1. Build the transfer map

Write the actual path down before editing:

```text
sender sources → descriptor/info-hash → QR/deep link → receiver parser
→ rendezvous hints → engine initial peers → metadata resolution → selection → download
```

At every arrow, identify the value that crosses the boundary. Do not infer it from UI state.

### 2. Diagnose “waiting”, “no peers”, or unresolved metadata

Check in this order:

1. Does the receiver have a valid content ID?
2. Does it have a discovery path: direct peer hint, tracker, DHT, or service lookup?
3. Does the engine receive those hints as its initial peers?
4. Is the sender actually seeding and listening on a bound TCP/UDP port?
5. Is that endpoint reachable from the receiver’s network and platform permissions?

A peer count of zero with an unresolved file list usually means the receiver has identity but no rendezvous path.

### 3. Bootstrap QR imports correctly

For in-person same-LAN sharing, include one or more direct peer hints in the inner P2P descriptor/magnet. Use the sender's:

- actual runtime listener port from the P2P engine;
- non-loopback, private LAN interface addresses;
- validated and bounded endpoint list.

Never derive a peer hint from a configured port range or a hard-coded conventional port. The configured range may not be the port the engine bound.

Wrap the descriptor in an app-owned deep link only for OS routing. Preserve the complete inner descriptor—including peer hints—through decode and validation.

### 4. Keep receiver actions receiver-only

A collection QR should follow this sequence:

```text
import remote descriptor
→ wait for metadata/file list
→ select intended entries
→ issue receiver-side download selection
```

It must not call a sender-only `publish`, `publishDraft`, or equivalent action. If manual imports require file selection, use a receiver-specific action label such as “Download selected files,” never “Share.”

### 5. Stage manual selections until explicit download

A receiver selection screen is a local editing surface, not an implicit transfer trigger:

```text
metadata/file list → locally stage checkboxes → explicit Download
                  → one receiver download-selection command → acquisition
```

- Toggling a file before the first download must update only presentation-local staged state. Do not dispatch a receiver command, wake an acquisition worker, or alter a durable selected set from a checkbox tap.
- Render the staged state immediately (including skipped/deselected affordances) so the person can inspect the exact final set.
- The Download button dispatches one complete, sorted selection—not a delta—and is the only action that may start a draft import.
- After a torrent is already running, selection revisions may be sent to the engine so it can reconcile the active transfer. Preserve this distinction between **draft staging** and **live revision**.
- Regression coverage must prove: a checkbox tap emits no command; Download emits exactly one receiver download command with the staged entries; the backend acquires only those file indexes.

### 6. Test before platform handoff

Create deterministic tests before changing implementation:

- share payload encodes direct endpoint hints;
- receiver parser reconstructs the exact endpoint list;
- engine bootstrap receives those peers;
- a collection-link/import flow sends import then download-selection, never publication;
- UI labels local handles, content hashes, and peer state honestly.

Then rebuild both devices and scan a **fresh** QR. Old QR values cannot acquire newly added metadata.

## Received Media Handoff to a Native Gallery

When a receiver's product policy is to place completed photos and videos into the native gallery automatically, model this as a **per-entry durable transition**, never as a collection-level toggle:

```text
verified receiver file → native gallery import/move → durable native reference
→ storage adapter rebinds the same torrent entry → no repeat download on restart
```

1. Trigger only after the engine reports the specific file as hash-verified and complete; never react to fetched/network byte counts.
2. Use an explicit image/video allow-list. Leave unsupported entries (documents, archives, etc.) in Portalis storage even when they share a collection with supported media.
3. Persist the native reference per imported entry (`phasset://<localIdentifier>` on iOS; `content://…` on Android), not merely a boolean that an entire collection was exported.
4. Re-register the **same collection** against a hybrid storage adapter: gallery-backed entries must be random-readable for resume/seeding, while app-folder entries remain writable for future selection/download work.
5. Do not replace a mixed collection with a read-only gallery-only storage factory; that breaks downloads of unsupported or previously unselected entries.
6. Treat PhotoKit/MediaStore completion and durable persistence as a recovery boundary. If the platform move succeeds but Portalis crashes before recording the reference, recovery must reconcile the native asset instead of blindly re-downloading or duplicating it.
7. When the platform API cannot atomically commit both the gallery asset and Portalis' durable reference, import/copy first, persist and rebind the native reference, then remove the app-local source last. Do not use a direct source-file move before the collection has been rebound unless a durable native-operation journal can recover the returned asset identifier.
8. Preserve incomplete receiver intent during a rebind: source records need declared torrent lengths and an explicit allowance for intentionally unselected/missing filesystem files. A hybrid adapter must read gallery references but continue to write filesystem-backed entries when a person selects them later.

See `references/received-gallery-hybrid-storage.md` for the receiver-storage and recovery checklist.

Verify this path on a physical device with: a media-only collection, a mixed media/document collection, denied library permission, interrupted import, app restart, and a subsequent re-download/seed check. A Linux test can validate the durable transition and planner, but cannot validate PhotoKit or MediaStore behavior.

## Transfer Timeline and Telemetry

When presenting P2P receive/upload history, make the transfer core—not the UI clock—the authority for timestamps and inactivity:

1. **Known zero is data.** If the engine sampled an interval and no receive/upload bytes moved, render its actual duration at `0 B/s`.
2. **Unknown is not zero.** App suspension, a backend restart, sampling failure, or pruned/unavailable history must render as a visual gap, never as fabricated inactivity.
3. **Default to the whole retained session.** Do not replace a truthful all-history view with a short live window. Offer zoom as an optional detail view.
4. **Store semantic segments, not repeated zeros.** Extend one `observed-zero`/`waiting`/`paused` segment across identical ticks; preserve phase boundaries and close with a terminal zero at completion.
5. **Render to the viewport budget.** Keep raw recent samples for detail, but serve all-history graphs as first/min/max/last (M4-style) envelope buckets sized to the chart width. Always retain segment boundaries; they carry pause, waiting, and gap semantics.
6. **Never synthesize a `now` sample in Flutter.** The backend must provide the current observed endpoint. A UI-created timestamp can stretch the x-axis and visually compress valid earlier history.

Tests must cover a known zero interval, an unknown gap, a terminal zero, and a short burst preserved by all-history aggregation. See `references/transfer-timeline-telemetry.md`.

## Owner Lifecycle and Truthful Transfer Presentation

Model **ownership/role** separately from **engine activity**. A published zero-copy owner already owns the original source bytes; an imported receiver does not. Engine startup, rehydration, or source verification must never erase that distinction.

1. Give published owners an explicit `Seeding`/sharing-ready lifecycle state once their durable source references and torrent handle exist. Do not project them as receiver `Preparing` or `Downloading` merely because a live engine reading has not arrived yet.
2. Retain the engine's source-check cursor separately from received/on-disk bytes. While a linked source is being verified, present it as local-source verification progress—not downloaded payload progress.
3. Keep user intent authoritative: `Draft` and `Paused` outrank engine activity. Treat verification failures or unavailable source references as actionable errors, rather than leaving a collection indefinitely in a generic preparing state.
4. Make presentation phase-specific:
   - **owner verifying:** source-verification percentage and local-source wording;
   - **ready/idle seed:** verified local-source total and sharing readiness;
   - **active seed:** uploaded bytes/rate and served peers, labeled seeding;
   - **receiver:** received/selected bytes, receive rate, ETA, and source peers.
5. Add regressions for fresh owner publication, owner restart before the first live reading, source verification, idle seeding, and active upload. Assert both status semantics and UI wording so a receiver-style `0 B of total` display cannot return unnoticed.

See `references/owner-seed-lifecycle-projection.md` for a condensed Portalis-style state/projection checklist.

## Presenting Peers Without Inventing Identity

A swarm peer carries no signed identity. Its address names a socket, and any
client name it announces is a string it chose. What you *can* vouch for is what
your own engine measured: bytes exchanged and current rates. Build the surface
around that asymmetry.

1. **Never pool verified contacts and anonymous peers into one list.** A person
   whose fingerprint was compared out of band and an address in a swarm are
   different kinds of thing. Give them separate sections with visibly different
   shapes — a stranger must never wear a contact's card, avatar, or verification
   badge.
2. **Lead a peer row with the address**, since it is the only element the
   device can confirm. Render a self-reported client name as an explicit claim
   (`reports qBittorrent 4.6`), never in the identity position.
3. **Do not attribute bytes to people.** Neither engine attributes transfer to a
   signed identity: a collection knows what it moved, not which member consumed
   it. A contact card showing a collection total wearing a person's name is a
   fabricated attribution. Byte figures belong on the connection, where they are
   measured.
4. **Measure peer rates between polls, not over the connection's lifetime.** A
   lifetime average keeps claiming a peer is working long after it went quiet.
   A peer seen for the first time has no prior sample, so it reports no rate
   rather than its whole connection compressed into one tick.
5. **Distinguish the real states.** *Moving* (show rates), *connected but idle*
   (say so — it is common and truthful), and *has exchanged nothing* are
   different. Showing a stale rate for a quiet peer is the same class of error
   as fabricating inactivity in a timeline.
6. **One connection per collection.** The same address connected for two
   collections is two connections; a flat parent/child pair preserves that.
   Merging them invents a single relationship the protocol does not have.

Pin with tests that a connection never renders a verification badge, that an
idle peer says idle rather than showing a rate, and that a self-reported name
appears as reported.

## Platform Considerations

- On iOS, declare local-network usage and handle the permission prompt. Use registered app URL schemes only for opening the app; the P2P engine still needs a real peer endpoint.
- On Android, do not substitute cache-file copies for gallery, MediaStore, or SAF sources. Add native random-access adapters for URI-backed media.
- For native galleries/files, retain platform references and read the original asset in the P2P storage adapter.

## Verification Checklist

- [ ] Sender is actively carrying/seeding the collection.
- [ ] Sender has a real bound listener port.
- [ ] Fresh QR contains a valid content ID and direct peer hints when using LAN bootstrap.
- [ ] Receiver parser preserves the hints.
- [ ] Receiver observes a nonzero peer or a concrete connection error rather than an unexplained wait.
- [ ] Receiver sends download-selection, never sender publication.
- [ ] No media source bytes were copied to make publication/discovery work.
- [ ] Relevant unit, integration, and device tests have passed.

## Common Pitfalls

- **“They are on the same network.”** This is network reachability, not discovery. Carry an endpoint or use an actual discovery mechanism.
- **Hard-coded `6881`.** The P2P engine may bind another available port in its configured range.
- **Raw info-hash QR.** It may identify the swarm without giving a private receiver any route to it.
- **Overloading drafts.** A local unpublished collection and a remote unresolved import are different workflows; never reuse sender terminology for receiver actions.
- **Copying to solve permissions.** Staging bytes creates storage and ownership bugs. Fix the native random-access source adapter instead.
- **Testing only parsing.** A valid QR parser proves nothing unless the endpoint reaches engine initial-peer configuration.

## References

- `references/portalis-qr-lan-bootstrap.md` — validated Portalis seam, regression cases, and zero-copy constraints.
