---
name: cross-platform-p2p-debugging
description: "Use for asymmetric mobile/desktop peer-transfer debugging."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, ios, android, linux, windows]
metadata:
  hermes:
    tags: [p2p, bittorrent, flutter, rust, mobile, desktop, networking]
    related_skills: [systematic-debugging, test-driven-development, flutter-rust-bridge]
---

# Cross-Platform P2P Debugging

## Use when

Use when a transfer, metadata lookup, peer bootstrap, QR/deep-link import, or
local-network operation works in one direction or platform but stalls in the
reverse direction.

## Core rule

A successful import is not proof of connectivity. Separate the pipeline into:

1. payload creation (magnet/QR/deep link);
2. payload parsing and validation;
3. sender listener binding;
4. sender interface enumeration and advertised endpoint construction;
5. receiver parsing and peer-hint propagation;
6. metadata inspection;
7. torrent acquisition.

Do not patch transport code until the first failing boundary is identified.

## Workflow

1. **Record the asymmetry.** Test A→B and B→A with the same content and record
   which stage each direction reaches. Preserve the exact UI state and runtime
   logs.
2. **Capture sender evidence.** At share/QR creation, log the live listener port
   and the complete validated advertised peer list. An empty list is a first-class
   result, not an implementation detail.
3. **Capture receiver evidence.** At import and metadata resolution, log the
   source's embedded peer hints and the hints supplied to the substrate. Confirm
   that parsing did not discard, rewrite, or duplicate them.
4. **Check platform prerequisites.** Verify local-network permission, sandbox or
   firewall rules, listener address family, interface visibility, VPN/cellular
   routing, and whether the advertised address is reachable from the receiver.
5. **Use a tight seam test.** Add a regression test for the first failing seam:
   peer-hint encoding/decoding, listener-address selection, interface filtering,
   command propagation, or metadata options. The test should fail before the
   fix and pass afterward.
6. **Change one boundary at a time.** Do not combine a new endpoint algorithm,
   fallback discovery, and UI changes in one patch. Re-run the directional test
   after each change.
7. **Verify the real target.** Run static checks and automated tests locally,
   then perform a rebuilt device-to-desktop and desktop-to-device transfer when
   the bug is platform-specific. Report native target validation separately from
   Linux-only validation.

## Required diagnostics

Use stable, redacted logs with these fields:

```text
share: listener_port=..., advertised_peers=[...]
import: source_peer_hints=[...], supplied_peer_hints=[...]
metadata: result=ok|error, file_count=..., error=...
acquire: peer_hints=[...], result=started|error
```

Never log source paths, credentials, tokens, or media contents. A magnet's info
hash and private LAN endpoint are sufficient for correlation; redact anything
else not needed to diagnose the transport.

## Common hypotheses to distinguish

- **No listener:** sender has no bound port, so QR contains no usable endpoint.
- **Wrong endpoint:** sender advertises a VPN, cellular, virtual, loopback, or
  otherwise unreachable address.
- **Address-family mismatch:** listener binds IPv6-only while the QR advertises
  IPv4, or the reverse.
- **Permission/firewall block:** the endpoint is correct but the platform denies
  local-network or incoming traffic.
- **Hint loss:** the receiver parses `x.pe` but does not pass it to metadata
  inspection or acquisition.
- **Metadata-only failure:** the peer connects, but the substrate cannot obtain
  or parse the torrent descriptor.

## Pitfalls

- Do not infer the root cause from a generic "waiting for file list" screen.
- Do not treat a QR scanner, deep-link import, or collection-row creation as a
  completed transfer.
- Do not retry speculative listener or IPv4/IPv6 changes without first checking
  the emitted listener and peer-hint diagnostics.
- Do not claim a cross-platform fix from Flutter tests alone; they cannot prove
  native camera, sandbox, local-network, or real peer reachability.
- If the exact runtime logs are unavailable, ask for the smallest evidence set:
  sender share diagnostics, receiver resolution diagnostics, and the exact
  imported magnet with secrets and unrelated query fields removed.

## Reference

See `references/directional-transfer-diagnostics.md` for the evidence matrix and
reproduction recipe from a real QR-to-metadata investigation.
