---
name: flutter-rust-bridge
description: "Use for Flutter-Rust bridge generation and API changes."
version: 1.0.0
---

# Flutter-Rust Bridge Engineering

## Use when

Use this skill when a Flutter application calls Rust through
`flutter_rust_bridge` (FRB): changing a bridged function or DTO, regenerating
bindings, reviewing generated output, or diagnosing codegen/build mismatches.

## Principles

- Keep the bridge **app-facing and explicit**. Export small DTOs and functions
  designed for Flutter; do not expose internal stores, core handles, traits, or
  domain graphs merely because codegen can see them.
- Generated bindings are build artifacts, not hand-maintained source. Change
  Rust inputs and generator configuration, then regenerate; never patch
  generated Dart or Rust as the lasting fix.
- Keep expensive or fast-moving state tiered. Prefer explicit summary, detail,
  history, and command channels over one universal snapshot that increases
  bridge traffic and Flutter allocation.
- For durable telemetry, make Rust the sole accounting authority: persist and
  deduplicate at backend lifecycle boundaries, compute effective live totals
  there, and expose presentation-ready DTOs. Flutter must not merge saved and
  live counters, infer epochs, or aggregate endpoint identity locally.
- Treat external links and QR payloads as untrusted input. Validate them before
  dispatching a bridged command; do not let a UI handle or display identifier
  masquerade as a durable cross-device identifier.

## Workflow

1. **Trace the current boundary.** Read the generator helper, its explicit Rust
   inputs, the public Rust API, generated Dart facade, app adapter, consumers,
   and test fakes before editing.
2. **Write a focused red test.** Cover the app-facing behavior or the smallest
   core boundary. Test an absent/invalid value as well as the successful bridge
   value where relevant.
3. **Change the real Rust boundary.** Keep DTOs owned and serializable. Return
   explicit `Option`/`Result` values instead of sentinel strings or invented
   identifiers.
4. **Classify the boundary change before codegen.** An internal Rust domain
   struct may carry new information between native adapter and projection
   without changing any exported `portalis_api` function or FRB DTO. In that
   case, do **not** regenerate merely because a Rust struct changed: confirm
   the generated public surface is unaffected, run the backend and Flutter
   compile/test gates, and keep the generated diff empty. Regenerate only when
   an exported Rust API, bridged DTO, generator input, or FRB version changed.
   For telemetry, keep transport counters (for example native received bytes)
   distinct from verified progress; label the UI by the counter's semantics so
   received-but-unverified bytes are never presented as completed content.
5. **Regenerate when the public boundary changed.** Invoke the repository
   helper from the directory it expects. Review every generated change; retain
   only output attributable to the intentional Rust/public-dependency change.
6. **Normalize generated Rust in the helper.** Some FRB versions emit Rust
   import ordering that fails `cargo fmt --check` despite compiling. Put
   `cargo fmt --all` immediately after codegen in the repository helper, then
   rerun the helper. Never manually format `src/api.rs` and call it fixed.
7. **Update adapter seams and test fakes.** An added repository/gateway method
   requires every fake implementation to implement it, usually with the most
   truthful unavailable/default response. Inspect generated DTO field types:
   FRB collection fields can be typed buffers such as `Uint32List`, so list
   literals are not always accepted in test seed data.
8. **Verify the combined tree.** Run the focused tests, Flutter analysis and
   suite, the generator, Rust formatting, and the repository Rust acceptance
   gate. Report target-specific build checks honestly when the required SDK is
   unavailable.

## Upgrading the FRB runtime and generator

When the package itself is upgraded, treat the Dart runtime, Rust crate, and
codegen executable as one matched toolchain. Update and regenerate them as a
single operation; do not use dependency overrides to force unrelated
transitive packages merely to silence `pub outdated`. Follow
[`references/matched-version-upgrades.md`](references/matched-version-upgrades.md)
for the exact resolution, generation, review, and verification sequence.

## Diagnosing generator messages

- A codegen diagnostic about duplicate internal type names or skipped
  unsupported internal types is not automatically a release failure. First
  inspect the generated public API and compile the generated Rust.
- It becomes a correctness problem if the ambiguous or skipped type is present
  in an exported function or DTO. Fix the public boundary—rename/contain the
  internal type or define a dedicated app-facing DTO—rather than suppressing
  diagnostics or exposing internals as opaque solely to hide a message.
- A generator run is successful only when it exits zero **and** the generated
  bindings compile through the repository's normal Rust/Flutter gates.

## Verification checklist

```sh
# From the Flutter package root
./tool/frb_build.sh
flutter analyze
flutter test

# From the Rust workspace root, or use the repository acceptance helper
cargo fmt --all --check
cargo test --workspace --all-targets --all-features
```

Follow any repository-specific integration/coverage script as the final gate.

## Native opaque-source adapters

When a native picker hands the app an opaque, permission-scoped source instead
of a filesystem path, preserve that identifier across Flutter and implement the
reader at the Rust platform-storage boundary. Never repair the boundary by
copying media into an app cache or by requesting picker byte data. See
[`references/android-no-copy-source-adapters.md`](references/android-no-copy-source-adapters.md)
for the Android Storage Access Framework and JNI descriptor pattern.

## Pitfalls

- Using a bare crate-wide generator input in a complex crate and accidentally
  traversing internal modules that are not bridgeable.
- Hand-editing generated files after codegen.
- Adding a method to the production adapter but forgetting test fakes.
- Treating a process-local backend handle as an importable or shareable ID.
- Claiming an iOS/Android deep-link handoff passed without installing a new
  native build and testing it on the device.
- Bumping the app's release version in only one of several files that must
  move together. A frontend commonly carries the version in more than one
  place — e.g. `pubspec.yaml`'s `version:`, the Rust crate's
  `Cargo.toml`/`Cargo.lock` version, and a Dart constant
  (`expectedBackendVersion`) the app checks against the live backend at
  startup. Bumping `pubspec.yaml` alone leaves the Dart constant stale, so the
  next real device run reports a compatibility mismatch (or silently trusts
  the wrong pair) even though nothing about the actual bridge changed. Grep
  every version-bearing file in the same commit as any version bump, and
  rebuild at least the backend crate afterward to confirm it still compiles
  at the new version before pushing.

## Reference

- `references/generated-output-hygiene.md` — compact notes on formatting FRB
  output and reviewing generator diagnostics.
- `references/choosing-a-bridge-tier.md` — deciding whether new data belongs in
  the summary snapshot, a dedicated call, or its own stream; flat parent/child
  pairs; polling a call-tier value from a Flutter screen without
  `setState`-during-build.
- `references/generated-collection-types.md` — handling FRB typed collection
  fields and keeping repository test seams truthful after a DTO change.
